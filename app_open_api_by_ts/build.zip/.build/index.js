"use strict";
console.log('app_open_api start by ts 1111222333444555666');
require('./app');
